

# Focused on business results! 
##                     ... enabled by practical AI
![Focus](./focus.svg)

---

# aiCue enables manufacturing companies to use data science for decision making across all activities for enhancing business results
- Focused on manufacturing companies
- Work across Marketing to Manufacturing to Quality to R&D

# Key strengths - Our 3D approach ensures business results
1. Domain knowledge – Auto/Manufacturing
2. Data, Processes and Change management
3. Data science tools

